angular.module('app.controllers', [])

  
.controller('menuCtrl', function($scope,$http) {

})

.controller('indexCtrl', function($scope) {
	//$scope.total = 10; 
})
   
.controller('loginCtrl', function($scope,$http,$ionicPopup,$ionicHistory,$state,$ionicLoading) {
		$scope.user = {};
		
		$scope.login = function() {
			  $ionicLoading.show({
			    content: 'Loading',
			    animation: 'fade-in',
			    showBackdrop: true,
			    maxWidth: 200,
			    showDelay: 0
			  });


			str="http://trons.16mb.com/user-details.php?e="+$scope.user.email+"&p="+$scope.user.password;
			$http.get(str,{timeout: 10000})

			.success(function (response){
				$ionicLoading.hide();
				$scope.user_details = response.records;
				localStorage.setItem('loggedin_name', $scope.user_details.u_name);
				localStorage.setItem('loggedin_id', $scope.user_details.u_id );
				localStorage.setItem('loggedin_phone', $scope.user_details.u_phone);
				localStorage.setItem('loggedin_address', $scope.user_details.u_address);
				localStorage.setItem('loggedin_gender', $scope.user_details.u_gender);

				
				//BUG to be fixed soon
				/*if(lastView.stateId=="checkOut"){ $state.go('checkOut', {}, {location: "replace", reload: true}); }
				else{*/
		        	$state.go('profile', {}, {location: "replace", reload: true});
				//}
				
			}).error(function(result, status, header, config){
				$ionicLoading.hide();
					var alertPopup = $ionicPopup.alert({
						title: 'Unable To Login',
						template: '<div style="text-align: center">[Periksa Email & Password]<br />---------ATAU----------<br />[Periksa jaringan Internet]</div>'
						
					});
			});
		};
		
})
   

.controller('profileCtrl', function($scope,$rootScope,$ionicHistory,$state) {
		
		$scope.loggedin_name= localStorage.getItem('loggedin_name');
		$scope.loggedin_id= localStorage.getItem('loggedin_id');
		$scope.loggedin_phone= localStorage.getItem('loggedin_phone');
		$scope.loggedin_address= localStorage.getItem('loggedin_address');
		$scope.loggedin_gender= localStorage.getItem('loggedin_gender');
$scope.logout=function(){
				delete localStorage.loggedin_name;
				delete localStorage.loggedin_id;
				delete localStorage.loggedin_phone;
				delete localStorage.loggedin_address;
				delete localStorage.loggedin_gender;
				
				console.log('Logoutctrl',localStorage.getItem('loggedin_id'));
				$ionicHistory.clearHistory()
				$ionicHistory.clearCache()
				$ionicHistory.nextViewOptions({
					disableAnimate: true,
					disableBack: true
				});
				$state.go('login', {}, {location: "replace", reload: true});
		};
		
		
})
   
