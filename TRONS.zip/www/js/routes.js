angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
      
        
    .state('menu', {
      url: '/page1',
      templateUrl: 'templates/menu.html',
      controller: 'menuCtrl'
    })
        
      
    
    
      
        
    .state('login', {
      url: '/page4',
      templateUrl: 'templates/login.html',
      controller: 'loginCtrl',
	  
		resolve:{
			"check":function($location){  
				if(localStorage.getItem('loggedin_id')){ $location.path('/page9');   }
				else									 {  $location.path('/page4');   }
			}
		}
    })
        
      
    
      
   
      
    
      
        
    .state('profile', {
      url: '/page9',
      templateUrl: 'templates/profile.html',
      controller: 'profileCtrl'  
    })
        
      
   
        
      
    ;

  // if none of the above states are matched, use this as the fallback
  if (localStorage.getItem('loggedin_id') == undefined) {
      $urlRouterProvider.otherwise('/page4');}
  else{
      $urlRouterProvider.otherwise('/page9');
  }

});